#!/bin/bash

RTH_CFG="ARemb.txt"

###############################################
# Installs Hypervisor on the given partition
#  $1 ... device
#  $2 ... partition number
###############################################
function installHypervisorFiles() {
	local hypDev=$1
	local hypPartNr=$2

	DEBUG_MESSAGE "installing RTS Hypervisor files on partition $hypDev$hypPartNr."

	if [ -z "$hypPartNr" ]; then
		printError "no partition number given."
	fi

	local arembSysPart=
	mountPartition arembSysPart $hypDev$hypPartNr

	local arembRthDir=$arembSysPart$RTH_DIR
	local RtsInstDir=$BASEAR_DIR"/System/RTH"
	
		# copy RTS file
	RTS_FILES=("rthx86" "license.txt")
	DEBUG_MESSAGE "mkdir -p $arembRthDir"
	if [ -z "$NO_ACTION" ]; then
		mkdir -p $arembRthDir
	fi
	for i in ${RTS_FILES[@]}
	do
		DEBUG_MESSAGE "cp -f $RtsInstDir/$i $arembRthDir/"
		if [ -z "$NO_ACTION" ]; then
			cp -f $RtsInstDir/$i $arembRthDir/
		fi
	done
	touch "$BASEAR_DIR/$RTH_TRACE_FILE"

	umountDir $arembSysPart
}

function installHypervisorCfg() {
	local hypDev=$1
	local hypPartNr=$2
	local extendedPartNr=$3
	local gpos=$4
	local bootline=$5
	local dramSizeInMb=$6

	DEBUG_MESSAGE "installing RTS Hypervisor configuration on partition $hypDev$hypPartNr for $gpos. bootline:$bootline, DRAM: ${dramSizeInMb}MB"

	if [ -z "$dramSizeInMb" ]; then
		printError "no dram size given."
	fi

	mountPartition arembSysPart $hypDev$hypPartNr

	local arembRthDir=$arembSysPart$RTH_DIR
	let extendedPartNr=$extendedPartNr-1

	local out="$arembRthDir/$RTH_CFG.dbg.txt"
	if [ -z "$NO_ACTION" ]; then
		out=$arembRthDir/$RTH_CFG
	fi
	DEBUG_MESSAGE "creating RTH Cfg in $out."

	let dramSizeInB=$dramSizeInMb*1024*1024

	local pcibus=
	local pcidevice=
	local pcifunction=
	local pciport=

	pcibus=$(lspci | grep "Class 0106" | cut -d ':' -f 1)
	pcidevice=$(lspci | grep "Class 0106" | cut -d ':' -f 2 | cut -d '.' -f 1 )
	pcifunction=$(lspci | grep "Class 0106" | cut -d ':' -f 2 | cut -d '.' -f 2 | cut -d ' ' -f 1 )
	pciport=$(lsscsi | grep "$hypDev" | cut -d '[' -f 2 | cut -d ':' -f 1 )

	echo "# RTH CONFIG"                                                  > $out
	echo ""                                                              >> $out
    echo "[/DRIVE/0/PARTITION/$extendedPartNr]"                          >> $out
    echo "    \"OS\"                     = uint32: 1"                    >> $out
    echo ""                                                              >> $out
    echo "[/DRIVE/0]"                                                    >> $out
    echo "    \"bus\"                    = uint32: 0x$pcibus"            >> $out
    echo "    \"default\"                = uint32: 0"                    >> $out
    echo "    \"device\"                 = uint32: 0x$pcidevice"         >> $out
    echo "    \"function\"               = uint32: 0x$pcifunction"       >> $out
    echo "    \"port\"                   = uint32: 0x$pciport"           >> $out
    echo ""                                                              >> $out
    echo "[/IO_RANGE/0]"                                                 >> $out    #IO range for MTCX
    echo "    \"base_port\"              = uint32: 0x4000"               >> $out
    echo "    \"length\"                 = uint32: 0x0200"               >> $out
    echo "    \"shared\"                 = uint32: 1"                    >> $out
    echo ""                                                              >> $out
    echo "# IO range for NMI"                                            >> $out
    echo "[/IO_RANGE/1]"                                                 >> $out
    echo "    \"OS\"                     = uint32: 1"                    >> $out
    echo "    \"base_port\"              = uint32: 0x61"                 >> $out
    echo "    \"length\"                 = uint32: 0x0001"               >> $out
    echo ""                                                              >> $out
    echo "# share IO range for POST codes"                               >> $out
    echo "[/IO_RANGE/2]"                                                 >> $out
    echo "    \"base_port\"              = uint32: 0x80"                 >> $out
    echo "    \"length\"                 = uint32: 0x0001"               >> $out
    echo "    \"shared\"                 = uint32: 1"                    >> $out
    echo ""                                                              >> $out
    echo "# IO range for I82371AB_DELAY() in vxbPiixStorage driver"      >> $out
    echo "[/IO_RANGE/3]"                                                 >> $out
    echo "    \"OS\"                     = uint32: 1"                    >> $out
    echo "    \"base_port\"              = uint32: 0x84"                 >> $out
    echo "    \"length\"                 = uint32: 0x0001"               >> $out
    echo "[/IRQ]"                                                        >> $out    #interrupts
    echo "    \"USB_SMI_disable\"        = uint32: 1"                    >> $out    #USB SMI wegen USB legacy abdrehen
    echo "    \"default\"                = uint32: 1"                    >> $out    #default is AR
    echo ""                                                              >> $out
	echo "[/OS/0/RUNTIME/0]"                                             >> $out
	if [ "$gpos" = "$WINDOWS_TAG" ]; then
		echo "    \"image_0\"                = \"(DRIVE0,0)\""           >> $out
	else
	    echo "    \"bootline\"               = \"$bootline\""            >> $out
	    echo "    \"image_0\"                = \"vmlinuz\""              >> $out
	    echo "    \"image_1\"                = \"initrd.img\""           >> $out
	fi
    echo ""                                                              >> $out
	echo "[/OS/0]"                                                       >> $out
	echo "    \"boot_priority\"          = uint32: 0"                    >> $out
	echo "    \"name\"                   = \"$gpos\""                    >> $out
	echo "    \"trace_partition_number\" = uint32: 0"                    >> $out
	echo "    \"virtualized\"            = uint32: 1"                    >> $out
	echo ""                                                              >> $out
    echo "[/OS/1/RUNTIME/0]"                                             >> $out
    echo "    \"bootline\"               = \"vnet(0,0) e=192.168.2.2\""  >> $out
    echo "    \"image_0\"                = \"arimg\""                    >> $out
    echo "    \"max_image_size_0\"       = uint32: 0x2000000"            >> $out
    echo ""                                                              >> $out
    echo "[/OS/1]"                                                       >> $out
    echo "    \"CPU\"                    = bytelist: 1"                  >> $out
    echo "    \"boot_priority\"          = uint32: 1"                    >> $out
    echo "    \"memory_size\"            = uint64: $dramSizeInB"         >> $out
    echo "    \"name\"                   = \"ARemb\""                    >> $out
    echo "    \"restricted_IO\"          = uint32: 1"                    >> $out
    echo "    \"virtual_MMU\"            = uint32: 1"                    >> $out
    echo ""                                                              >> $out
    echo "[/PCI/0]"                                                      >> $out
    echo "    \"OS\"                     = uint32: 1"                    >> $out	#all B&R devices => AR
    echo "    \"vendor_ID\"              = uint32: 0x1677"               >> $out
    echo ""                                                              >> $out
    echo "[/PCI/1]"                                                      >> $out	#SATA controller => GPOS
    echo "    \"OS\"                     = uint32: 0"                    >> $out
    echo "    \"bus\"                    = uint32: 0x$pcibus"            >> $out
    echo "    \"device\"                 = uint32: 0x$pcidevice"         >> $out
    echo "    \"function\"               = bytelist: $pcifunction"       >> $out
    echo "    \"interrupt_mode\"         = uint32: 2"                    >> $out
    echo ""                                                              >> $out
    echo "[/PCI]"                                                        >> $out
    echo "    \"default\"                = uint32: 1"                    >> $out    #default is AR
    echo ""                                                              >> $out
    echo "[/SHM/0]"                                                      >> $out    #shared memory
    echo "    \"name\"                   = \"trace\""                    >> $out
    echo "    \"size\"                   = uint64: 0x4000"               >> $out
    echo ""                                                              >> $out
    echo "[/SYSTEM]"                                                     >> $out
    echo "    \"IOMMU\"                  = uint32: 0"                    >> $out
    echo ""                                                              >> $out
    echo "[/TIME_SYNC]"                                                  >> $out
    echo "    \"auto_start\"             = uint32: 1"                    >> $out
    echo "    \"master\"                 = uint32: 0"                    >> $out
    echo "    \"sync_interval\"          = uint32: 1000"                 >> $out
    echo ""                                                              >> $out

	umountDir $arembSysPart
}

