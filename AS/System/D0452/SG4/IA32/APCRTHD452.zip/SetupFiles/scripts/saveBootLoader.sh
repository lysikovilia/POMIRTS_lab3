#!/bin/bash

SAVED_MASTER_BOOT_RECORD_FILE_NAME="SavedBootloader.mbr"

SECTORS_TO_SAVE=128

#########################################################
# Saves the boot loader of the given partition
# (MBR and the following $SECTORS_TO_SAVE-1 sectors)
#  $1 ... device
#  $2 ... partition number
#  $3 ... GPOS
##########################################################
function saveBootLoader() {

	local device=$1
	local partNr=$2

	DEBUG_MESSAGE "saving boot loader of disc $device on partition $device$partNr"

	if [ -z "$partNr" ]; then
		printError "no partNr given. saveBootLoader($device, $partNr)"
	fi

	# mount boot partition 
	local BootDir=
	local bootLoaderBackup=

	mountPartition BootDir $device$partNr
	retv=$?
	if [ "$retv" != "0" ]; then
		let partNr=$partNr+1
		mountPartition BootDir $device$partNr
		retv=$?
	fi

	if [ "$retv" = "0" ]; then
		bootLoaderBackup=$BootDir"/"$SAVED_MASTER_BOOT_RECORD_FILE_NAME

		DEBUG_MESSAGE "saving boot loader of device $device ($SECTORS_TO_SAVE sectors) to file $bootLoaderBackup"

		if [ -z "$bootLoaderBackup" ]; then
			printError "no boot loader backup file given."
		fi

		# save MBR if not already done
		if [ ! -e "$bootLoaderBackup" ]; then
			# save original MBR (sector 0) + Grub Stage 1.5 (sectors 1-$SECTORS_TO_SAVE)
			DEBUG_MESSAGE "dd if=$device of=$bootLoaderBackup bs=512 count=$SECTORS_TO_SAVE"
			if [ -z "$NO_ACTION" ]; then
				dd if=$device of=$bootLoaderBackup bs=512 count=$SECTORS_TO_SAVE
				retv=$?
				if [ "$retv" = "0" ]; then
					DEBUG_MESSAGE "boot loader successfully saved"
				else		# error => delete corrupt file
					rm $bootLoaderBackup
					DEBUG_MESSAGE "error: boot loader not saved"
				fi
			fi
		else
			DEBUG_MESSAGE "boot loader was already saved"
		fi

		umountDir $BootDir
	fi
	return $retv
}

#########################################################
# Restores the master boot record from the given partition
#  $1 ... device
#  $2 ... partition number
##########################################################
function restoreBootLoader() {
	local device=$1
	local partNr=$2

	DEBUG_MESSAGE "restore MBR of device $device from $device$partNr"

	if [ -z "$partNr" ]; then
		printError "no partNr given. restoreBootLoader ($device, $partNr)"
	fi

	# mount boot partition
	local BootDir=
	local bootLoaderBackup=

	mountPartition BootDir $device$partNr
	local retv=$?
	if [ "$retv" != "0" ]; then
		let partNr=$partNr+1
		mountPartition BootDir $device$partNr
		retv=$?
	fi

	if [ "$retv" = "0" ] ;then
		# windows
		bootLoaderBackup=$BootDir"/"$SAVED_MASTER_BOOT_RECORD_FILE_NAME
		if [ ! -e "$bootLoaderBackup" ] ; then
			# no saved MBR file found => error!
			retv=1
		fi
		if [ -z "$bootLoaderBackup" ] ;then
			retv=1
		fi

		if [ "$retv" = "0" ] ;then
			DEBUG_MESSAGE "restoring MBR and boot loader of device $device from $bootLoaderBackup"

			# restore MBR
			DEBUG_MESSAGE "dd if=$bootLoaderBackup of=$device bs=446 count=1"
			if [ -z "$NO_ACTION" ]; then
				dd if=$bootLoaderBackup of=$device bs=446 count=1
				retv=$?
				if [ "$retv" = "0" ]; then			#Bootsektor-Signatur setzen
					#seek=250 && bs=2 => skip 510bytes (0-509, write to byte 510, 511)
					DEBUG_MESSAGE "writing boot sector signature 0x55AA"
					echo -e "\x55\xaa" | awk '{printf "%s\n", $_}' | dd of=$device bs=2 seek=255 count=1
					retv=$?
				fi
				if [ "$retv" = "0" ]; then
					let sectors=$SECTORS_TO_SAVE-1
					DEBUG_MESSAGE "dd if=$bootLoaderBackup of=$device bs=512 skip=1 seek=1 count=$sectors"
					if [ -z "$NO_ACTION" ]; then
						dd if=$bootLoaderBackup of=$device bs=512 skip=1 seek=1 count=$sectors
						retv=$?
						if [ "$retv" = "0" ]; then		# well done => can delete saved MBR file
							rm $bootLoaderBackup
						fi
					fi
				fi
			fi
		fi
		umountDir $BootDir
	fi
	return $retv
}

# checks 
function getGpos() {
	local __gpos=$1 
	local grubDev=$2
	local grubPartNr=$3
	local bootMBR=$4

	local gpos=
	
	DEBUG_MESSAGE "getting GPOS of device $grubDev$grubPartNr, MBR: $bootMBR"

	if [ -z "$bootMBR" ]; then
		printError "no master boot record given."
	fi

	gpos=$(echo $bootMBR | sed 's/  */ /g' | sed -e 's/^[ \t]*//')   #trim spaces, remove leading spaces

	DEBUG_MESSAGE "detected GPOS: $gpos"

	eval "${__gpos}='${gpos}'"
}
