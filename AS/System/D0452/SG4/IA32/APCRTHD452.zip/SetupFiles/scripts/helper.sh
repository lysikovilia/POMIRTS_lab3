#!/bin/bash
# installARemb.sh - A menu driven shell script to install ARemb on an APC.
# Author: Peter Maier
# Date: 12/Jun/2016

WINDOWS_TAG="Windows"
LINUX_TAG="Linux"
AR_SYSTEM_DIR="/SYSTEM"
GRUB_DIR=$AR_SYSTEM_DIR"/GRUB"
RTH_DIR=$AR_SYSTEM_DIR"/RTH"

mountedDirIndex=1

# Purpose: Display pause prompt
# $1-> Message (optional)
function pause(){
	local message="$@"
	[ -z $message ] && message="Press [Enter] key to continue, [ESC] to exit..."
	read -p "$message" readEnterKey
	if [ "$readEnterKey" = $'\e' ]; then		# ESC
		exit 0;
	fi
}

function DEBUG_MESSAGE() {
	if [ -n "$DEBUG_MODE" ]; then
		local noAction=
		if [ -n "$NO_ACTION" ]; then
			noAction="NO_ACTION: "
		fi
		echo "$noAction${BASH_SOURCE[1]}:${BASH_LINENO[0]}: $@"
		if [ -n "$STEPPING_MODE" ]; then
			pause
		fi
	fi
	LAST_DEBUG_MESSAGE="$@"
}

function printError() {
	echo "${BASH_SOURCE[1]}:${BASH_LINENO[0]}: $@"
	echo "last debug msg: $LAST_DEBUG_MESSAGE"
	exit 1
}

function getSubStringContaining (){
	local __result=$1
	local string=$2
	local searchString=$3
	local tmpString=
	local result=

	DEBUG_MESSAGE "getSubStringContaining($__result, $string, $searchString)"
	if [ -z "$searchString" ]; then
		printError "no search string given. getSubStringContaining($__result, $string, $searchString)"
	fi

	string=$(echo $string | sed 's/  */ /g' | sed -e 's/^[ \t]*//')   #trim spaces, remove leading spaces
	while [ -n "$string" ]
	do 
		tmpString=$(echo $string | cut -d ' ' -f1)

		if [ -z "$tmpString" ]; then
			break;
		else
			if [[ "$tmpString" =~ "$searchString" ]]; then
				result=$tmpString
				break;
			fi
		fi 
		newString=$(echo $string | cut -d ' ' -f2-)		# "shift"
		if [ "$newString" = "$string" ]; then
			string=
		else
			string=$newString
		fi
	done

	eval "$__result='$result'"
}


# extracts the i-th substring with given delimiter 
# $1 ... i 
# $2 ... delim
# $3 ... string
# return ... value in RESULTING_SUBSTRING
function getIthSubstringWithDel(){
	idx=0
	cnt=0
	tmpString=$3
	while [ "$cnt" -lt "$1" ]
	do 
		idx=$(echo `expr index "$tmpString" $2`)		# index of ":"
		tmpString=${tmpString:$idx}
		let cnt=cnt+1
	done

	idx=$(echo `expr index "$tmpString" $2`)		# index of ":"
	let idx=idx-1
	tmpString=${tmpString:0:$idx}
	RESULTING_SUBSTRING=$tmpString
}
	
function isdigit_within(){    # Tests whether *entire string* is numerical and within the borders.
             # In other words, tests for integer variable.
	SUCCESS=0
	FAILURE=1

	digit=$1
	min=$2
	max=$3

	[ $# -eq 3 ] || return $FAILURE

	case $digit in
    	*[!0-9]*|"") return $FAILURE;;
            	*) :;;
	esac

	if (( ("$min" <= "$digit") && ("$digit" <= "$max") )); then
		return $SUCCESS
	else
		return $FAILURE
	fi 
}

function mountPartition() {
	local __mountedDir=$1
	local devicePartNr=$2

	local mountedDir="/mnt/part"

	if [ -z "$devicePartNr" ]; then
		printError "no device and partition number given. mountPartition ($__mountedDir, $devicePartNr)"
	fi

	mountedDir=$mountedDir$mountedDirIndex
	let mountedDirIndex=$mountedDirIndex+1

	DEBUG_MESSAGE "mkdir -p $mountedDir"
	mkdir -p $mountedDir

	DEBUG_MESSAGE "mount $devicePartNr $mountedDir"
	mount $devicePartNr $mountedDir
	local retv=$?
	if [ "$retv" = "0" ]; then
		local isNtfs=$(mount | grep $devicePartNr | grep "type ntfs")
		if [ -n "$isNtfs" ]; then		#remount
			DEBUG_MESSAGE "umount $mountedDir"
			umount $mountedDir
			DEBUG_MESSAGE "ntfsfix $devicePartNr"		#fix NTFS filesystem
			ntfsfix $devicePartNr
			DEBUG_MESSAGE "mount -t ntfs-3g $devicePartNr $mountedDir"
			mount -t ntfs-3g $devicePartNr $mountedDir
			retv=$?
		fi
	else
		DEBUG_MESSAGE "ntfsfix $devicePartNr"		#fix NTFS filesystem
		ntfsfix $devicePartNr
		DEBUG_MESSAGE "mount -t ntfs-3g $devicePartNr $mountedDir"
		mount -t ntfs-3g $devicePartNr $mountedDir
		retv=$?
	fi

	eval $__mountedDir=$mountedDir
	return $retv
}

function umountDir() {
	local dir=$1

	DEBUG_MESSAGE "umount $dir"
	if [ -z "$dir" ]; then
		printError "no dir given. umountDir ($dir)"
	fi

	umount $dir
	rmdir $dir
}

# Sets file attributes
# 1 ... read-only
# 2 ... hidden
# 4 ... system
FILE_ATTRIBUTE_READONLY=1
FILE_ATTRIBUTE_HIDDEN=2
FILE_ATTRIBUTE_SYSTEM=4
let "FILE_ATTRIBUTE_NTFS_ALL=$FILE_ATTRIBUTE_READONLY | $FILE_ATTRIBUTE_HIDDEN | $FILE_ATTRIBUTE_SYSTEM"
function setNtfsAttributes() {
	local file=$1
	local attr=$2

	DEBUG_MESSAGE "set attributes of $file, attribute: $attr"

	echo "do nothing - geht noch nicht?"
	return 0

	if [ -z "$attr" ]; then
		printError "no attr given. setAttribute ($file, $attr)"
	fi
	DEBUG_MESSAGE "getfattr -h -e hex -n system.ntfs_attrib_be $file \| grep system.ntfs_attrib_be \| cut -d '=' -f 2"
	local currentAttr=$(getfattr -h -e hex -n system.ntfs_attrib_be $file | grep system.ntfs_attrib_be | cut -d '=' -f 2)
	let "currentAttr=$currentAttr | $attr"

	DEBUG_MESSAGE "setfattr -h -v $currentAttr -n system.ntfs_attrib_be $file"
	$(setfattr -h -v $currentAttr -n system.ntfs_attrib_be $file)
}

function clearNtfsAttributes() {
	local file=$1
	local attr=$2

	DEBUG_MESSAGE "clear attributes of $file, attribute: $attr"

	if [ -z "$attr" ]; then
		printError "no attr given. setAttribute ($file, $attr)"
	fi
	DEBUG_MESSAGE "getfattr -h -e hex -n system.ntfs_attrib_be $file \| grep system.ntfs_attrib_be \| cut -d '=' -f 2"
	local currentAttr=$(getfattr -h -e hex -n system.ntfs_attrib_be $file | grep system.ntfs_attrib_be | cut -d '=' -f 2)
	let "currentAttr=$currentAttr & ~$attr"

	DEBUG_MESSAGE "setfattr -h -v $currentAttr -n system.ntfs_attrib_be $file"
	$(setfattr -h -v $currentAttr -n system.ntfs_attrib_be $file)
}

if [ -n "$DEBUG_MODE" ]; then
	echo "debug ($DEBUG_MODE_PARAM):                on"
	if [ -n "$STEPPING_MODE" ]; then 
		singleSteps="on"
	else
		singleSteps="off"
	fi
	if [ -n "$NO_ACTION" ]; then 
		noAction="on"
	else
		noAction="off"
	fi
	echo "single steps ($STEPPING_MODE_PARAM): $singleSteps"
	echo "no actions ($NO_ACTION_PARAM):       $noAction"
	pause
fi
